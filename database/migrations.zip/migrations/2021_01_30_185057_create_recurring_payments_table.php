<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRecurringPaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('recurring_payments', function (Blueprint $table) {
            $table->id();
            $table->string('email');
            $table->float('payment_amount');
            $table->integer('user_id')->unsigned()->nullable();
            $table->string('intervals');
            $table->date('start_date');
            $table->boolean('is_active')->default(1);
            $table->timestamps();
            $table->softDeletes();


            $table->foreign('user_id', 'foreign_recurring_user_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recurring_payment');
    }
}
