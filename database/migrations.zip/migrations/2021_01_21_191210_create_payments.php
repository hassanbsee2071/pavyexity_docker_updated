<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePayments extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('transaction_id')->unsigned();
            $table->string('email')->nullable();
            $table->integer('user_id')->unsigned()->nullable();
            $table->integer('sender_id')->unsigned();
            $table->boolean('is_guest')->default(0);
            $table->float('payment_amount');
            $table->integer('payment_details_id')->nullable();
            $table->string('payment_type');
            $table->string('payment_status');
            $table->boolean('is_reoccuring')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('sender_id', 'foreign_sender_user_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
            $table->foreign('transaction_id', 'foreign_transaction_id')
                ->references('id')
                ->on('transactions')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
