<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->text('transaction_id')->nullable();
            $table->text('transaction_type')->nullable();
            $table->integer('user_id')->unsigned()->nullable();
            $table->float('transaction_amount');
            $table->string('transaction_name');
            $table->text('transaction_description');
            $table->enum('transaction_status', ['successful', 'failed','processing']);
            $table->text('reference_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('user_id', 'foreign_tranasction_user')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaction');
    }
}
