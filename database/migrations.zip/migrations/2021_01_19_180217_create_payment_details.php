<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_details', function (Blueprint $table) {
            $table->id();
            $table->string('payment_method');
            $table->string('email');
            $table->integer('user_id')->nullable();
            $table->float('payment_amount');
            $table->string('account_number')->nullable();
            $table->string('routing_number')->nullable();
            $table->integer('account_type')->unsigned()->nullable();
            $table->text('bank_account_name')->nullable();
            $table->string('card_holder_name')->nullable();
            $table->string('card_number')->nullable();
            $table->text('address_line_1')->nullable();
            $table->text('address_line_2')->nullable();
            $table->text('city')->nullable();
            $table->text('state')->nullable();
            $table->text('country')->nullable();
            $table->integer('zipcode')->nullable();
            $table->integer('CVV')->nullable();
            $table->integer('month')->unsigned()->nullable();
            $table->integer('year')->unsigned()->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment_details');
    }
}
